import cv2
import mediapipe as mp
import time
import pyautogui
import numpy as np

class handDetector():
    def __init__(self, mode=False, maxHands=2, detectionCon=0.5, modelComplexity=1, trackCon=0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.detectionCon = detectionCon
        self.modelComplex = modelComplexity
        self.trackCon = trackCon

        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(self.mode, self.maxHands, self.modelComplex, self.detectionCon, self.trackCon)
        self.mpDraw = mp.solutions.drawing_utils

    def findHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)
        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, self.mpHands.HAND_CONNECTIONS)
        return img

    def findPosition(self, img, handNo=0, draw=True):
        lmlist = []
        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]
            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                lmlist.append([id, cx, cy])
                if draw:
                    if id in [4, 8, 12, 16, 20]:
                        cv2.circle(img, (cx, cy), 5, (123, 33, 8), cv2.FILLED)
        return lmlist


cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)
detector = handDetector(detectionCon=0.5)
pTime = 0

fingertips = [4, 8, 12, 16, 20]

# Variables for virtual mouse
frame_width = 1280
frame_height = 720
screenWidth, screenHeight = pyautogui.size()
canvas = np.zeros((frame_height, frame_width, 3), dtype=np.uint8)
drawing = False
sensitivity = 2
scale_factor = 2
frame_count = 0
skip_frames = 1

while True:
    success, img1 = cap.read()
    img1=cv2.flip(img1,1)
    img = detector.findHands(img1)
    lmlist = detector.findPosition(img)

    # Hand gesture recognition for signing
    if(lmlist):
        if len(lmlist)>=9:
          fingers=[]

          if lmlist[fingertips[0]][1]>lmlist[fingertips[0]-1][1]:
                fingers.append(0)
          else:
              fingers.append(1)
          for id in range(1,5):
             if lmlist[fingertips[id]][2]<lmlist[fingertips[id]-2][2]:
                 fingers.append(1)
             else:
              fingers.append(0)

             cv2.rectangle(img, (10, 40), (225, 100), (10, 2, 0), thickness=4)
             print(fingers)
             if fingers == [1, 1, 1, 1, 1] or fingers == [0, 1, 0, 0, 0]:
                cv2.putText(img1, "Move", (40, 80), cv2.FONT_HERSHEY_PLAIN, 2, (12, 12, 255), 3)
             elif fingers == [0, 0, 0, 0, 0]:
                cv2.putText(img1, "Shoot", (40, 80), cv2.FONT_HERSHEY_PLAIN, 2, (12, 12, 255), 3)
         
    # Virtual mouse implementation
    if frame_count % skip_frames == 0:
        rgbConvertedFrame = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        output = detector.hands.process(rgbConvertedFrame)
        hands = output.multi_hand_landmarks

        if hands:
            for hand in hands:
                if not drawing:
                    canvas[:] = 0
                detector.mpDraw.draw_landmarks(canvas, hand, mp.solutions.hands.HAND_CONNECTIONS,
                                               landmark_drawing_spec=detector.mpDraw.DrawingSpec(color=(255, 0, 255), thickness=5, circle_radius=1))
                landmarks = hand.landmark
                all_fingers_closed = True
                for id, landmark in enumerate(landmarks):
                    if id == 6:
                        y_base = landmark.y * frame_height
                    elif id == 8:
                        y_tip = landmark.y * frame_height
                        if y_tip < y_base:
                            x = int(landmark.x * frame_width)
                            y = int(y_tip)
                            mousePositionX = screenWidth * x / (frame_width * scale_factor)
                            mousePositionY = screenHeight * y / (frame_height * scale_factor)
                            pyautogui.moveTo(mousePositionX * sensitivity, mousePositionY * sensitivity)
                        elif y_tip > y_base:
                            if all_fingers_closed:
                                pyautogui.click()

    img_resized = cv2.resize(img1, (frame_width, frame_height))
    canvas_resized = cv2.resize(canvas, (frame_width, frame_height))
    combined_img = cv2.addWeighted(img_resized, 0.5, canvas_resized, 0.5, 0)

    cv2.imshow('SIGN DETECTOR', img)
    #cv2.imshow('Virtual Mouse', combined_img)
    frame_count += 1

    key = cv2.waitKey(1)
    if key == ord('x'):
        break


cap.release()
cv2.destroyAllWindows()
